﻿namespace LogProcess.Model
{
    public class LogProcessCt
    {
        public string Hash { get; set; } // Primary key
        public string TypeTransaction { get; set; }
        public string Request { get; set; }
        public string MessageResult { get; set; }
        public DateTime DateTransaction { get; set; }
    }
}
