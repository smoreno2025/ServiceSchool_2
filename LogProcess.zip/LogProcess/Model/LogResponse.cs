﻿namespace LogProcess.Model
{
    public class LogResponse
    {
        public LogProcessCt Log { get; set; }

        public string Mesage { get; set; }
        public bool Error { get; set; }
    }
}
