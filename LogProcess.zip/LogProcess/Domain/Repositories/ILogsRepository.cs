using System.Collections.Generic;
using System.Threading.Tasks;
using LogProcess.Model;

namespace Domain.Repositories;
public interface ILogsRepository
{
    Task<LogProcessCt> AddLogProcess(LogProcessCt process);
    Task<LogResponse> GetInfoLogHash(string id);
}