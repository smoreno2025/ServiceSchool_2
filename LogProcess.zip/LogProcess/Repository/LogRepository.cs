using Domain.Repositories;
using LogProcess.Infrastructure;
using LogProcess.Model;
using LogProcess.Resources;
using Microsoft.EntityFrameworkCore;
using System.Reflection;
using System.Resources;

namespace LogProcess.Repository
{
    public class LogRepository : ILogsRepository
    {
        private readonly SchoolContext _context;

        public LogRepository(SchoolContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Guardar informacion de log de procesos
        /// </summary>
        /// <param name="process">Informacion de proceso</param>
        /// <returns></returns>
        /// <exception cref="System.Exception"></exception>
        public async Task<LogProcessCt> AddLogProcess(LogProcessCt process)
        {
            try
            {
                _context.LogProcess.Add(process);
                await _context.SaveChangesAsync();
                return process;
            }
            catch (System.Exception ex)
            {
                throw new System.Exception(Resource.MessageException, ex);
            }
        }

        public async Task<LogResponse> GetInfoLogHash(string Hash)
        {
            try
            {
                LogResponse response = new LogResponse();
                LogProcessCt Log = await _context.LogProcess.FirstOrDefaultAsync(s => s.Hash == Hash);
                if (Log == null)
                {
                    response.Error = true;
                    response.Mesage = string.Format(LogProcess.Resources.Resource.MessageNoFound, Hash);
                }
                else
                {
                    response.Error = false;
                    response.Log = Log;
                    response.Mesage = string.Format(LogProcess.Resources.Resource.FoundMessage, Hash);
                }
                return response;
            }
            catch (System.Exception ex)
            {
                throw new System.Exception(string.Format(LogProcess.Resources.Resource.MessageException, Hash));
            }
        }
    }
}