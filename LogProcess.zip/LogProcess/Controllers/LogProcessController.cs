﻿using LogProcess.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ServiceSchool.Application.Services;

namespace LogProcess.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LogProcessController : ControllerBase
    {
        private readonly ILogService _studentService;
        public LogProcessController(ILogService studentService)
        {
            _studentService = studentService;
        }

        [HttpPost("AddLogProcess")]
        public async Task<IActionResult> AddLogProcess(LogProcessCt log)
        {
            try
            {
                LogProcessCt createdLog = await _studentService.AddLogProcess(log);
                return Ok(true);
            }
            catch (System.Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Ocurrió un error al consultar los logs de proceso.");
            }
        }


        [HttpGet("GetLogProcessByHash")]
        public async Task<IActionResult> GetLogProcessByHash(string log)
        {
            try
            {
                LogResponse createdLog = await _studentService.GetInfoLogHash(log);
                return Ok(createdLog);
            }
            catch (System.Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Ocurrió un error al consultar los logs de proceso.");
            }
        }
    }
}
