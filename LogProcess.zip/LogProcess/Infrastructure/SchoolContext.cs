using Microsoft.EntityFrameworkCore;
using LogProcess.Model;

namespace LogProcess.Infrastructure
{
    public class SchoolContext : DbContext
    {
        public SchoolContext(DbContextOptions<SchoolContext> options) : base(options) { }

        public DbSet<LogProcessCt> LogProcess { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<LogProcessCt>().HasKey(s => s.Hash);
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<LogProcessCt>().HasData(
           new LogProcessCt
           {
               Hash = "1233545sms",
               MessageResult = "Exitoso",
               Request = "GetData",
               DateTransaction = DateTime.Now,
               TypeTransaction = "Post"
           }
       );

        }
    }
}