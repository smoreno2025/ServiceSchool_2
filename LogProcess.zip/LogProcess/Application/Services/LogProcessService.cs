using ServiceSchool.Application.Services;
using Domain.Repositories;
using LogProcess.Model;

public class LogProcessService : ILogService
{
    private readonly ILogsRepository _repository;

    public LogProcessService(ILogsRepository repository)
    {
        _repository = repository;
    }


    public async Task<LogProcessCt> AddLogProcess(LogProcessCt process)
        => await _repository.AddLogProcess(process);

    public async Task<LogResponse> GetInfoLogHash(string hash)
    => await _repository.GetInfoLogHash(hash);
}