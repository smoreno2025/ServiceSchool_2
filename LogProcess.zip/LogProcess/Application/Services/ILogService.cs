using LogProcess.Model;

namespace ServiceSchool.Application.Services
{
    public interface ILogService
    {
        Task<LogProcessCt> AddLogProcess(LogProcessCt process);

        Task<LogResponse> GetInfoLogHash(string hash);
    }
}